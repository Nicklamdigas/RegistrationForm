# Registration Form (Java Swing + MySQL)

This project is a simple registration form built with Java Swing, storing user data in a MySQL database. It displays all registered users in a table.

## Setup

### 1. MySQL Database

- Open XAMPP and start MySQL.
- Use phpMyAdmin to run `registrationdb.sql` to create the database and table.

### 2. Java

- Download [MySQL Connector/J](https://dev.mysql.com/downloads/connector/j/) and add the JAR to your classpath.
- Compile with:
  ```
  javac RegistrationFormMySQL.java
  ```
- Run with:
  ```
  java RegistrationFormMySQL
  ```
- Make sure MySQL is running and you use the default user/password (`root` / no password).

## Files

- `registrationdb.sql`: SQL to set up database and table.
- `RegistrationFormMySQL.java`: Source code for the form.

## Screenshots

See assignment images for reference.

## Notes

- This project does not use PHP; only Java and MySQL.
- Modify DB connection details in `RegistrationFormMySQL.java` as needed for your setup.
